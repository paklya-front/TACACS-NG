/*
 * h_rmd.c
 *
 * (C)1998-2011 by Marc Huber <Marc.Huber@web.de>
 * All rights reserved.
 *
 * $Id: 35e73e03db9e8978bf4ee6ffad645bf25d22476a $
 *
 */

#include "headers.h"

static const char rcsid[] __attribute__((used)) = "$Id: 35e73e03db9e8978bf4ee6ffad645bf25d22476a $";

void h_rmd(struct context *ctx, char *arg)
{
    char *t;
    struct stat st;

    DebugIn(DEBUG_COMMAND);

    if ((t = buildpath(ctx, arg)) && (strlen(t) > ctx->rootlen) && !pickystat(ctx, &st, t) && S_ISDIR(st.st_mode) && !rmdir(t))
	reply(ctx, MSG_250_Directory_removed);
    else
	reply(ctx, MSG_550_Permission_denied);

    DebugOut(DEBUG_COMMAND);
}
