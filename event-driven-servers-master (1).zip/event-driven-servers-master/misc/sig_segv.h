/*
 * sig_segv.h (C)1999-2011 by Marc Huber <Marc.Huber@web.de>
 *
 * $Id: sig_segv.h,v 1.6 2011/07/10 14:16:59 marc Exp $
 *
 */

#ifndef __SIG_SEGV__
#define __SIG_SEGV__
void setup_sig_segv(char *, char *, char *);
#endif				/* __SIG_SEGV__ */
