A couple of certs for testing.

Passphrase for the .pfx archives is

   secret


